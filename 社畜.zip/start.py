#导入前置/ 736 * 552
from tkinter import *
import tkinter.filedialog as filedialog
import tkinter.messagebox as messagebox
import ctypes
#import os
import sys

file = ''


def shake():
    global file
    if file == ("jie"):
       messagebox.showerror(title="失败",message="未指定文件")
    #定义

def main():
    path_work = sys.path[0]
    root = Tk()
    root.title("社畜-V0.1")
     #    root.iconbitmap('C://Users//节炎五呜呜//Desktop//PY//fs//ico//milk.ico')
    mouse = PhotoImage(file= path_work + "//ico//ICON.png")
    root.iconphoto(False,mouse)
    root.geometry('687x497')
    root.maxsize(687, 497)    # 设置窗口最大值
    root.minsize(687, 497)    # 设置窗口最小值

    ctypes.windll.shcore.SetProcessDpiAwareness(1)
    #获取屏幕的缩放因子
    ScaleFactor=ctypes.windll.shcore.GetScaleFactorForDevice(0)
    #设置程序缩放
    root.tk.call('tk', 'scaling', ScaleFactor/75)


    #确定布局
    login = Button(root,text="START",command=shake,font=("微软雅黑",20),bg="gray")

    name_label = Label(root,text="账户名称",font=("微软雅黑",14))
    name_Entry = Entry(root,width=40)
    psw_Label = Label(root,text="账户名称",font=("微软雅黑",14))
    psw_Entry = Entry(root,width=40)
    test = Label(text=("TEST"))
    #button1 = Button(root,text="点击选择文件",command=select_file,font=("微软雅黑",8),bg="azure")
    #   Button4 = Button(root,text="选择",font=("微软雅黑",9))



    #显示部分

    login.grid(row=4,columnspan=6,pady=9)
    name_label.grid(row=1,column=1,padx=23)
    name_Entry.grid(row=1,column=2,pady=50)
    test.grid(row=1,column=3,padx=40)
    psw_Label.grid(row=2,column=1,padx=23)
    psw_Entry.grid(row=2,column=2,pady=50)
    #button1.grid(row=1,column=4,padx=50)
    #   Button4.grid(row=2,column=2,padx=3)

    #后置

    root.mainloop()
main()